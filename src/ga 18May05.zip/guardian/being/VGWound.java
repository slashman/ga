package guardian.being;

import util.*;

public class VGWound extends ObjectVector{
	public GWound elementAt(int i){
		return (GWound) v.elementAt(i);
	}
}