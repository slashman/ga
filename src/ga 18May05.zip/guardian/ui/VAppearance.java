package guardian.ui;

public class VAppearance extends util.ObjectVector {
	public Appearance elementAt(int i){
		return (Appearance) v.elementAt(i);
	}
}