package guardian.ui;

import engine.*;

public interface PlayerActionListener {
	public void playerActionSelected(Action a);

}