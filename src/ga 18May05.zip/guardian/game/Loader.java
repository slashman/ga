/*
 * Loader.java
 *
 * Created on 2 de septiembre de 2004, 19:18
 */

package guardian.game;

public interface Loader {
    
    public void load();
    
}
