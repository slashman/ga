package guardian.world;

import util.*;

public class VEvent extends ObjectVector {
	public Event elementAt(int i){
		return (Event) v.elementAt(i);
	}

}