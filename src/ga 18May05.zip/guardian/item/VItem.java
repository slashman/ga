package guardian.item;

import util.*;

public class VItem extends ObjectVector{


	public GItem elementAt(int i){
		return (GItem) v.elementAt(i);
	}

}