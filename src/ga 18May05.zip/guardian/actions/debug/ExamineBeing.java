package guardian.actions.debug;

public class ExamineBeing {


}