package uiLayers.consoleUI;

public class ActionCancelException extends Exception {


}